package com.sg.stocks.vo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class StockPricesVO {
	@JsonIgnore
	private Date stockDate;
	private String symbol;
	private float open;
	private float close;
	private float low;
	private float high;
	private int volume;
	private String sDate;
	private static SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	
	public Date getStockDate() {
		return stockDate;
	}
	public void setStockDate(Date stockDate) {
		this.stockDate = stockDate;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public float getOpen() {
		return open;
	}
	public void setOpen(float open) {
		this.open = open;
	}
	public float getClose() {
		return close;
	}
	public void setClose(float close) {
		this.close = close;
	}
	public float getLow() {
		return low;
	}
	public void setLow(float low) {
		this.low = low;
	}
	public float getHigh() {
		return high;
	}
	public void setHigh(float high) {
		this.high = high;
	}
	public int getVolume() {
		return volume;
	}
	public void setVolume(int volume) {
		this.volume = volume;
	}
	

	public static StockPricesVO populateVO(String[] arr) throws ParseException {
		StockPricesVO stock = new StockPricesVO();
		stock.setStockDate(format.parse(arr[0]));
		stock.setSymbol(arr[1]);
		stock.setOpen(Float.parseFloat(arr[2]));
		stock.setClose(Float.parseFloat(arr[3]));
		stock.setLow(Float.parseFloat(arr[4]));
		stock.setHigh(Float.parseFloat(arr[5]));
		stock.setVolume(Math.round(Float.parseFloat(arr[6])));
		return stock;
	}
	public String getsDate() {
		return sDate;
	}
	public void setsDate(String sDate) {
		this.sDate = sDate;
	}
}
