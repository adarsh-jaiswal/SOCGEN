package com.sg.stocks.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
@Embeddable
public class StockPk implements Serializable {

	private static final long serialVersionUID = 1L;
	private Date stockDate;
	private String symbol;
	
	@Column(name = "STOCK_DATE")
	public Date getStockDate() {
		return stockDate;
	}
	public void setStockDate(Date stockDate) {
		this.stockDate = stockDate;
	}
	@Column(name = "SYMBOL")
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	
}
