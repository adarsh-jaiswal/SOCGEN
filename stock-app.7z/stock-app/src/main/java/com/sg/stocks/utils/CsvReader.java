package com.sg.stocks.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import com.sg.stocks.dao.StockDao;
import com.sg.stocks.entity.Stock;
import com.sg.stocks.vo.StockPricesVO;

@Component
public class CsvReader {
	
	@Autowired
	private StockDao stockDao;
	
	private static final String STOCK_FILE_PATH = "classpath:stock_prices.csv";
	private static final String COMMA_DELIMITER = ",";
	
	public void readAndDumpToDb() throws IOException, ParseException {
		StockPricesVO stockVo = null;
		BufferedReader stream = null;
		String line = null;
		try{
			stream = new BufferedReader(new FileReader(ResourceUtils.getFile(STOCK_FILE_PATH)));
			stream.readLine();
			
			long startTime = System.nanoTime();
			
			while ((line = stream.readLine()) != null) {
				String[] splitted = line.split(COMMA_DELIMITER);
				stockVo = StockPricesVO.populateVO(splitted);
				stockDao.saveStock(stockVo);
			}
			long endTime = System.nanoTime();
			System.out.println((endTime - startTime) +"mili seconds");
		}catch(Exception e) {
		}
		
		finally {
			if (stream != null)
				stream.close();
		}
		
	}
}
