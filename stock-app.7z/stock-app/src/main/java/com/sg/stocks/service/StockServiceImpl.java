package com.sg.stocks.service;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sg.stocks.dao.StockDao;
import com.sg.stocks.utils.CsvReader;
import com.sg.stocks.vo.StockPricesVO;

@Service
@Transactional
public class StockServiceImpl implements StockService {

	
	@Autowired
	private StockDao stockDao;
	
	@Autowired
	private CsvReader reader;

	@Override
	public List<StockPricesVO> getStock(String stockName) {
		return stockDao.getStock(stockName);
	}

	@Override
	public List<String> getStocksName() {
		return stockDao.allStockName();
	}

	@Override
	public void saveStocks() {
		try {
			reader.readAndDumpToDb();
		} catch (IOException e) {
			
		} catch (ParseException e) {
			
		}
	}

}
