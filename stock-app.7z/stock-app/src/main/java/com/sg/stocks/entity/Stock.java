package com.sg.stocks.entity;

import java.text.SimpleDateFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.sg.stocks.vo.StockPricesVO;

@Entity
@Table(name = "STOCKS")
public class Stock {
	private StockPk pk;
	private float open;
	private float close;
	private float low;
	private float high;
	private int volume;
	private static SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	@Id
	public StockPk getPk() {
		return pk;
	}
	public void setPk(StockPk pk) {
		this.pk = pk;
	}
	@Column(name = "STOCK_OPEN")
	public float getOpen() {
		return open;
	}
	public void setOpen(float open) {
		this.open = open;
	}
	@Column(name = "STOCK_CLOSE")
	public float getClose() {
		return close;
	}
	public void setClose(float close) {
		this.close = close;
	}
	@Column(name = "LOW")
	public float getLow() {
		return low;
	}
	public void setLow(float low) {
		this.low = low;
	}
	@Column(name = "HIGH")
	public float getHigh() {
		return high;
	}
	public void setHigh(float high) {
		this.high = high;
	}
	@Column(name = "VOLUME")
	public int getVolume() {
		return volume;
	}
	public void setVolume(int volume) {
		this.volume = volume;
	}
	
	public static Stock convertToEntity(StockPricesVO vo) {
		Stock entity = new Stock();
		StockPk pk = new StockPk();
		pk.setStockDate(vo.getStockDate());
		pk.setSymbol(vo.getSymbol());
		entity.setPk(pk);
		entity.setOpen(vo.getOpen());
		entity.setClose(vo.getClose());
		entity.setLow(vo.getLow());
		entity.setHigh(vo.getHigh());
		entity.setVolume(vo.getVolume());
		return entity;
	}
	
	public StockPricesVO convertToVo() {
		StockPricesVO vo = new StockPricesVO();
		vo.setStockDate(this.pk.getStockDate());
		vo.setSymbol(this.pk.getSymbol());
		vo.setOpen(this.getOpen());
		vo.setClose(this.getClose());
		vo.setLow(this.getLow());
		vo.setHigh(this.getHigh());
		vo.setVolume(this.getVolume());
		vo.setsDate(format.format(this.pk.getStockDate()));
		return vo;
	}
	

}
