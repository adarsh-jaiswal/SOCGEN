package com.sg.stocks.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.sg.stocks.entity.Stock;
import com.sg.stocks.vo.StockPricesVO;

@Repository
public class StockDaoImpl implements StockDao {

	@PersistenceContext
    private EntityManager em;
	
	@Override
	public void saveStock(StockPricesVO stock) {
		try {
			Query updateQuery = em.createNativeQuery("INSERT INTO stocks (STOCK_DATE, SYMBOL, STOCK_OPEN, STOCK_CLOSE, LOW, HIGH, VOLUME) VALUES (:date, :symbol, :open, :close, :low, :high, :volume)");
			updateQuery.setParameter("date", stock.getStockDate());
			updateQuery.setParameter("symbol", stock.getSymbol());
			updateQuery.setParameter("open", stock.getOpen());
			updateQuery.setParameter("close", stock.getClose());
			updateQuery.setParameter("low", stock.getLow());
			updateQuery.setParameter("high", stock.getHigh());
			updateQuery.setParameter("volume", stock.getVolume());
			updateQuery.executeUpdate();
		}  catch(Exception ex) {
			System.out.println(ex);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<StockPricesVO> getStock(String symbol) {
		List<StockPricesVO> stockList = null;
		try {
			Query query = em.createQuery("from Stock where symbol=:stockName");
			query.setParameter("stockName", symbol);
			List<Stock> stockObj = (List<Stock>) query.getResultList();
			if (stockObj != null && !stockObj.isEmpty()) {
				stockList = new ArrayList<StockPricesVO>();
				for (Stock ob : stockObj) {
					stockList.add(ob.convertToVo());
				}
			}
		}  catch(Exception ex) {
			System.out.println(ex);
		}
		return stockList;
	
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> allStockName() {
		List<String> list = null;
		try {
			Query query = em.createNativeQuery("Select distinct symbol from stocks");
			 list = query.getResultList();
		}  catch(Exception ex) {
			System.out.println(ex);
		}
		return list;
	}

}
