package com.sg.stocks.dao;

import java.util.List;

import com.sg.stocks.vo.StockPricesVO;

public interface StockDao {
	void saveStock(StockPricesVO stock);
	List<StockPricesVO> getStock(String symbol);
	List<String> allStockName();
}
