package com.sg.stocks.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sg.stocks.service.StockService;
import com.sg.stocks.vo.StockPricesVO;

@Controller
public class StockController {
	
	@Autowired
	private StockService stockService;
	
	@RequestMapping(value="/",method=RequestMethod.GET)
	public ModelAndView displayHomePage() {
		ModelAndView modelAndView = new ModelAndView("index");
		return modelAndView;
	}
	
	@ResponseBody
	@RequestMapping(value="/stocks",method=RequestMethod.GET)
	public ResponseEntity<?> getAllStocks() {
		List<String> stocks = stockService.getStocksName();
		return new ResponseEntity<List<String>>(stocks, HttpStatus.OK);
	}
	@ResponseBody
	@RequestMapping(value="/stocks/{stockName}",method=RequestMethod.GET)
	public ResponseEntity<?> getStock(@PathVariable(value = "stockName") String stockName) {
		List<StockPricesVO> stockVo = stockService.getStock(stockName);
		return new ResponseEntity<List<StockPricesVO>>(stockVo, HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(value="/dumpdata",method=RequestMethod.GET)
	public String saveStocks() {
		stockService.saveStocks();
		return "data saved";
	}
}
