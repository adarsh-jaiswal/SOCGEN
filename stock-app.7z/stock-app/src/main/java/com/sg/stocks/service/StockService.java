package com.sg.stocks.service;

import java.util.List;

import com.sg.stocks.vo.StockPricesVO;

public interface StockService {
	List<String> getStocksName();
	List<StockPricesVO> getStock(String stockName);
	void saveStocks();
}
