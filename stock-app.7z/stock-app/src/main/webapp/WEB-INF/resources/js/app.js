var app=angular.module('myApp',["ngRoute"])
.run(function($rootScope,$http,$location) {
	$rootScope.current_user ='';
	$rootScope.authenticated=false;
});

app.config(function($routeProvider){
	$routeProvider .when('/', {
		templateUrl: 'resources/html/main.html',
		controller: 'stockController'
	});
});


app.controller('stockController', function($scope,$http,$rootScope,$location){
	
	$scope.pageSize = 10;
	$scope.currentPage = 0;
	$scope.pageInput = 1;
	
	
	/**
	 * Pagination Start
	 */
	
	$scope.setPage = function (pageNumber) {
		if (null != pageNumber) {
			$scope.currentPage = pageNumber;
			$scope.pageInput = pageNumber + 1;
		}
	}
	
	$scope.setPageOnKeyPress = function (event) {
		if (null != event && event.which === 13) {
			if ($scope.pageInput < 1
					|| !((($scope.pageInput - 1) * $scope.pageSize) < ($scope.allStocks.length))) {
				
				alert("Invalid number.");
				return;
			}
			$scope.currentPage = $scope.pageInput - 1;
		}
	}
	
	/**
	 * Pagination End
	 */
	
	$scope.fetchAllStocks = function() {
		$scope.allStocks = [] ; 
		$http({
			method:'GET',
			url:'stocks',
		}).then(function(response){
			if(response.data != '') {
				//$scope.allStocks = response.data ; 
				angular.forEach(response.data , function(item , index ){
					
					$scope.allStocks.push({
						'item': item   ,
						'number'  : index + 1 
						
					})
				});
				$scope.totalPages = Math.ceil($scope.allStocks.length / $scope.pageSize);
			
			}

		});
	};
	$scope.fetchAllStocks();
	$scope.stockDetails = [] ;
	$scope.selected = null ;
	$scope.getStockDetails = function(stockName) {
		$scope.selected = stockName ;
		$http({
			method:'GET',
			url:'stocks/'+ stockName,
		}).then(function(response) {
			if(response.data != '') {
				$scope.stockDetails = response.data ;
			} else {
				
			}
		});
	}
	$scope.reverse = false ;
	
	$scope.orderByMe = function(x) {
	    $scope.myOrderBy = x;
	    $scope.reverse = !$scope.reverse;
	  }
	
});

